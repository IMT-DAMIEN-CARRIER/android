package com.example.tpnoteandroid;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.TextView;

import com.example.tpnoteandroid.modele.SolMars;
import com.example.tpnoteandroid.view.WindDirectionView;

public class SolView extends AppCompatActivity {

    @SuppressLint("DefaultLocale")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sol_view);

        SolMars solMars = (SolMars) getIntent().getSerializableExtra("SOLMARS");

        final TextView solName = (TextView) findViewById(R.id.sol_name);
        final TextView solTemperature = (TextView) findViewById(R.id.sol_temperature);
        final TextView solPressure = (TextView) findViewById(R.id.sol_pressure);

        solName.setText(String.format("Sol n°%s", solMars.getId()));

        solTemperature.setText(
                String.format(
                        "Temperature : avg : %d min : %d max : %d",
                        solMars.getAvgTemp(),
                        solMars.getMinTemp(),
                        solMars.getMaxTemp()
                )
        );

        solPressure.setText(
                String.format(
                        "Pression : avg : %d min : %d max : %d",
                        solMars.getAvgPres(),
                        solMars.getMinPres(),
                        solMars.getMaxPres()
                )
        );

        WindDirectionView view = findViewById(R.id.wind_direction_view);
        view.setSolMars(solMars);
    }
}