package com.example.tpnoteandroid.view;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;

import androidx.annotation.Nullable;

import com.example.tpnoteandroid.R;
import com.example.tpnoteandroid.modele.SolMars;

import java.util.ArrayList;

public class WindDirectionView extends View {
    Paint mars;
    Paint wind;
    Paint line;
    SolMars solMars;

    public WindDirectionView(Context context) {
        super(context);
        init();
    }

    public WindDirectionView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public WindDirectionView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        Resources resources = getResources();

        this.mars = new Paint();
        this.mars.setStyle(Paint.Style.FILL);
        this.mars.setColor(resources.getColor(R.color.copper_red));

        this.wind = new Paint();
        this.wind.setStyle(Paint.Style.FILL);
        this.wind.setStrokeWidth(4);
        this.wind.setColor(resources.getColor(R.color.blue));

        this.line = new Paint();
        this.line.setStyle(Paint.Style.FILL);
        this.line.setStrokeWidth(5);
        this.line.setColor(resources.getColor(R.color.black));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int width = getWidth();

        float size = ((float) width / 2) - 50;

        canvas.translate((float) width / 2, (float) width / 2);
        canvas.drawCircle(0, 0, size, this.mars);

        canvas.drawLine(0, 0, 0, -size, this.line);
        canvas.drawLine(0, 0, size, 0, this.line);
        canvas.drawLine(0, 0, 0, size, this.line);
        canvas.drawLine(0, 0, -size, 0, this.line);

        ArrayList winds = solMars.getWind();
        int maxCT = solMars.getMaxWind();

        if (null != winds) {
            canvas.rotate(-90f);
            double teta = 360f / 16;

            for (int i = 0; i < winds.size(); i++) {
                ArrayList wind = (ArrayList) winds.get(i);

                int degree = (int) wind.get(0);
                int ct = (int) wind.get(1);
                Log.d("width", " width" +width);

                float longueur = (ct / maxCT) * size;

                canvas.rotate(degree);

                Path path = new Path();
                path.lineTo((float) Math.cos(Math.toRadians(-teta / 2)) * longueur, (float) Math.sin(Math.toRadians(-teta / 2)) * longueur);
                path.lineTo((float) Math.cos(Math.toRadians(teta / 2)) * longueur, (float) Math.sin(Math.toRadians(teta / 2)) * longueur);
                path.lineTo(0,0);
                path.close();

                canvas.drawPath(path, this.wind);
                canvas.rotate((float) teta);
            }
        }
    }

    public SolMars getSolMars() {
        return solMars;
    }

    public void setSolMars(SolMars solMars) {
        this.solMars = solMars;
        this.invalidate();
    }
}
