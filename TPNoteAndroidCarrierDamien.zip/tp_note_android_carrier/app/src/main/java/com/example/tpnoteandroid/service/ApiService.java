package com.example.tpnoteandroid.service;

import android.content.Context;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.tpnoteandroid.modele.SolMars;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ApiService {
    private static final String URL = "https://www.billygirboux.fr/sols.json";

    private RequestQueue queue;
    private static ApiService instance;

    public static ApiService getInstance(Context context)
    {
        if (null == instance) {
            instance = new ApiService(context);
        }

        return instance;
    }

    private ApiService(Context context)
    {
        this.queue = Volley.newRequestQueue(context);
    }

    public Promise<List<SolMars>> getSolMars() {
        Promise<List<SolMars>> promise = new Promise<>();
        List<SolMars> solsMarsList = new ArrayList<>();

        JsonObjectRequest request = new JsonObjectRequest(
                Request.Method.GET,
                URL,
                null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        ArrayList<String> solMarsIdList = new ArrayList<>();

                        try {
                            JSONArray solJsonArray = response.getJSONArray("sol_keys");

                            for (int i = 0; i < solJsonArray.length(); i++) {
                                solMarsIdList.add(solJsonArray.getString(i));
                            }

                            for (String sol : solMarsIdList) {
                                solsMarsList.add(new SolMars(sol, response.getJSONObject(sol)));
                            }

                            promise.promiseThen.onResponse(solsMarsList);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        if (null != promise.promiseCatch) {
                            promise.promiseCatch.onResponse(error.getMessage());
                        }
                    }
                }
        );

        queue.add(request);

        return promise;
    }
}
