package com.example.tpnoteandroid.service;

public interface CallbackInterface<T> {
    void onResponse(T t);
}
