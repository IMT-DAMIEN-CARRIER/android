package com.example.tpnoteandroid;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.tpnoteandroid.modele.SolMars;
import com.example.tpnoteandroid.service.ApiService;
import com.example.tpnoteandroid.service.CallbackInterface;
import com.example.tpnoteandroid.service.SolMarsArrayAdapter;

import org.json.JSONObject;

import java.util.List;

public class HomeActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        ApiService apiService = ApiService.getInstance(getApplicationContext());
        final ListView listView = (ListView) findViewById(R.id.home_listView);

        apiService.getSolMars()
                .then(new CallbackInterface<List<SolMars>>() {
                            @SuppressLint("DefaultLocale")
                            @Override
                            public void onResponse(List<SolMars> solsMars) {
                                SolMarsArrayAdapter adapter = new SolMarsArrayAdapter(
                                        getApplicationContext(),
                                        solsMars
                                );

                                listView.setAdapter(adapter);

                                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                    @Override
                                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                        SolMars solMars = (SolMars) solsMars.get(position);

                                        openSolViewActivity(solMars);
                                    }
                                });

                                Toast.makeText(
                                        HomeActivity.this,
                                        R.string.data_received,
                                        Toast.LENGTH_SHORT
                                ).show();
                            }
                        }
                )
                .catchError(new CallbackInterface<String>() {
                    @Override
                    public void onResponse(String s) {
                        Toast.makeText(
                                HomeActivity.this,
                                "Error",
                                Toast.LENGTH_SHORT
                        ).show();
                    }
                });
    }

    public void openSolViewActivity(SolMars solMars) {
        Intent intent = new Intent(this, SolView.class);
        intent.putExtra("SOLMARS", solMars);
        startActivity(intent);
    }
}