package com.example.tpnoteandroid.service;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.example.tpnoteandroid.R;
import com.example.tpnoteandroid.modele.SolMars;

import java.util.List;

public class SolMarsArrayAdapter extends ArrayAdapter<SolMars> {
    List<SolMars> solsMars;

    public SolMarsArrayAdapter(@NonNull Context context, List<SolMars> solsMars) {
        super(context, 0, solsMars);
        this.solsMars = solsMars;
    }

    @SuppressLint("DefaultLocale")
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View rowView = convertView;

        if (null == rowView) {
            rowView = LayoutInflater.from(this.getContext()).inflate(
                    R.layout.layout_sol,
                    parent,
                    false
            );
        }

        SolMars solMars = this.solsMars.get(position);

        final TextView textView = (TextView) rowView.findViewById(R.id.textView_sol);
        final TextView textViewTemp = (TextView) rowView.findViewById(R.id.textView_sol_temperature);
        final TextView textViewPres = (TextView) rowView.findViewById(R.id.textView_sol_pressure);

        textView.setText(String.format("Sol n°%s", solMars.getId()));
        textViewTemp.setText(String.format("Temperature : %d", solMars.getAvgTemp()));
        textViewPres.setText(String.format("Pression : %d", solMars.getAvgPres()));

        return rowView;
    }
}
