package com.example.tpnoteandroid.modele;

import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;

public class SolMars implements Serializable {
    String id;

    int avgTemp;
    int maxTemp;
    int minTemp;
    int ctTemp;

    int avgPres;
    int maxPres;
    int minPres;
    int ctPres;

    ArrayList wind = new ArrayList();

    int maxWind;

    public SolMars(String id, JSONObject jsonObject) throws JSONException {
        this.id = id;

        this.loadFromJSONObject(jsonObject);
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getAvgTemp() {
        return avgTemp;
    }

    public void setAvgTemp(int avgTemp) {
        this.avgTemp = avgTemp;
    }

    public int getMaxTemp() {
        return maxTemp;
    }

    public void setMaxTemp(int maxTemp) {
        this.maxTemp = maxTemp;
    }

    public int getMinTemp() {
        return minTemp;
    }

    public void setMinTemp(int minTemp) {
        this.minTemp = minTemp;
    }

    public int getCtTemp() {
        return ctTemp;
    }

    public void setCtTemp(int ctTemp) {
        this.ctTemp = ctTemp;
    }

    public int getAvgPres() {
        return avgPres;
    }

    public void setAvgPres(int avgPres) {
        this.avgPres = avgPres;
    }

    public int getMaxPres() {
        return maxPres;
    }

    public void setMaxPres(int maxPres) {
        this.maxPres = maxPres;
    }

    public int getMinPres() {
        return minPres;
    }

    public void setMinPres(int minPres) {
        this.minPres = minPres;
    }

    public int getCtPres() {
        return ctPres;
    }

    public void setCtPres(int ctPres) {
        this.ctPres = ctPres;
    }

    public ArrayList getWind() {
        return wind;
    }

    public void setWind(ArrayList wind) {
        this.wind = wind;
    }

    public int getMaxWind(){
        int max = 0;

        for (int i = 0; i < this.wind.size(); i++){
            ArrayList windArray = (ArrayList) this.wind.get(1);

            int value = (int) windArray.get(1);

            if (value > max) {
                max = value;
            }
        }

        return max;
    }

    private void loadFromJSONObject(JSONObject jsonObject) {
        try {
            JSONObject temperatureJson = (JSONObject) jsonObject.get("AT");
            JSONObject pressureJson = (JSONObject) jsonObject.get("PRE");
            JSONObject windJson = (JSONObject) jsonObject.get("WD");

            this.avgTemp = temperatureJson.getInt("av");
            this.maxTemp = temperatureJson.getInt("mx");
            this.minTemp = temperatureJson.getInt("mn");
            this.ctTemp = temperatureJson.getInt("ct");

            this.avgPres = pressureJson.getInt("av");
            this.maxPres = pressureJson.getInt("mx");
            this.minPres = pressureJson.getInt("mn");
            this.ctPres = pressureJson.getInt("ct");

            for (int i = 0; i < windJson.length(); i++) {
                if (windJson.has(String.valueOf(i))) {
                    JSONObject windDetails = (JSONObject) windJson.get(String.valueOf(i));

                    ArrayList windArray = new ArrayList(
                            Arrays.asList(
                                    windDetails.getInt("compass_degrees"),
                                    windDetails.getInt("ct")
                            )
                    );

                    this.wind.add(windArray);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
