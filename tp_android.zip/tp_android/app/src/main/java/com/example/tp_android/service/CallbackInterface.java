package com.example.tp_android.service;

public interface CallbackInterface<T> {
    void onResponse(T t);
}
