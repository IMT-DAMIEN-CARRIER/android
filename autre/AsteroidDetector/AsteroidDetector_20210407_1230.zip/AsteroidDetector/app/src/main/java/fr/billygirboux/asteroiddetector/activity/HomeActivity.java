package fr.billygirboux.asteroiddetector.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toast;

import java.util.List;

import fr.billygirboux.asteroiddetector.R;
import fr.billygirboux.asteroiddetector.model.Asteroid;
import fr.billygirboux.asteroiddetector.service.APIService;
import fr.billygirboux.asteroiddetector.service.Callback;

public class HomeActivity extends AppCompatActivity {

    private APIService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        this.apiService = APIService.getInstance(getApplicationContext());

        this.apiService.getAsteroids()
                .then(new Callback<List<Asteroid>>() {
                    @Override
                    public void onResponse(List<Asteroid> asteroids) {
                        Toast.makeText(HomeActivity.this, "NB Asteroids" + asteroids.size(), Toast.LENGTH_SHORT).show();
                    }
                }).catchError(new Callback<String>() {
                    @Override
                    public void onResponse(String error) {
                        Toast.makeText(HomeActivity.this, "Error:" + error, Toast.LENGTH_SHORT).show();
                    }
                });

        this.apiService.getAsteroids(
                new Callback<List<Asteroid>>() {
                    @Override
                    public void onResponse(List<Asteroid> asteroids) {
                        Toast.makeText(HomeActivity.this, "NB Asteroids" + asteroids.size(), Toast.LENGTH_SHORT).show();
                    }
                },
                new Callback<String>() {
                    @Override
                    public void onResponse(String error) {
                        Toast.makeText(HomeActivity.this, "Error:" + error, Toast.LENGTH_SHORT).show();
                    }
                }
        );
    }
}