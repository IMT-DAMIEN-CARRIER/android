package com.example.ds_app.service;

public interface OnError {
    void treatError();
}
